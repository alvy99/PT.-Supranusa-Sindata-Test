describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://e1-vhp.com/fr/reservation')
  })
})
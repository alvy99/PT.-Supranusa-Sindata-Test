describe('Login Feature - Visual Hotel Program', () => {
  // Impor fungsi login
  const { login } = require('../support/login');

  beforeEach(() => {
    // Panggil fungsi login
    login();
  });

  it('TC001 - Should login successfully with valid credentials', () => {
    // Verifikasi elemen di dashboard setelah login (contoh: header dashboard)
   /* cy.get('div[data-v-6039fe0e].col-xs-6.col-md-4.text-center') // Selector header dari gambar sebelumnya
      .should('exist')
      .should('be.visible')
      .should('contain.text', 'DATABASE TRAINING USR.1 - JAKARTA'); */
  });
});
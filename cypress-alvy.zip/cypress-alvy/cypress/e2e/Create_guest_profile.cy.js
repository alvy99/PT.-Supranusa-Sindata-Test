describe('Guest Profile Management', () => {
  // Impor fungsi login
  const { login } = require('../support/login');

  // Jalankan login 
  beforeEach(() => {
    login();
  });

  it('should create a new guest profile', () => {
    // untuk mengisi form
    cy.get('div[data-v-60b17918].column.items-center.justify-center.full-height.cursor-pointer')
        .should('exist')
        .should('be.visible');
    cy.get('a:contains("Create Guest Profile Individual")').click();
    cy.wait(1000);

    // Mengisi form
    // Personal Information
    cy.get('input[name="lastName"]') 
      .type('Smith');
    cy.get('input[name="firstName"]') 
      .type('John');
    cy.get('select[name="title"]') 
      .select('Mr');
    cy.get('select[name="gender"]') 
      .select('Male');
    cy.get('select[name="country"]') 
      .select('IDN - INDON');
    cy.get('select[name="nation"]') 
      .select('IDN - INDON');

    // Additional Information
    cy.get('input[name="birthdate"]') 
      .type('01/01/1990');
    cy.get('input[name="birthplace"]') 
      .type('Jakarta');



    // Klik tombol Save
    cy.get('button:contains("SAVE")')
      .click();

    // Verifikasi keberhasilan
    cy.contains('Guest profile created successfully') // Ganti dengan pesan sukses yang sesuai
      .should('be.visible');
  });
});
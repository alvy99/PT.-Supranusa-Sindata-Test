const login = () => {
  cy.visit('https://e1-vhp.com/login');

  // Mengisi username
  cy.get('input[placeholder="Username"]')
    .type('qctest@qcbali03')
    .should('have.value', 'qctest@qcbali03');

  // Mengisi password
  cy.get('input[placeholder="Password"]')
    .type('test123')
    .should('have.value', 'test123');

  // Mengisi CAPTCHA
  cy.get('[data-cy="captcha-input-login"]')
    .should('be.visible')
    .type('A3b9Z1')
    .should('have.value', 'A3b9Z1');

  // Klik tombol Login
  cy.get('.q-btn:contains("Log in")', { timeout: 10000 })
    .should('be.visible')
    .click();

  // Tunggu hingga dashboard dimuat
  cy.wait(2000);

  // Verifikasi URL dashboard
  cy.url().should('include', 'https://e1-vhp.com/');
};

module.exports = { login };